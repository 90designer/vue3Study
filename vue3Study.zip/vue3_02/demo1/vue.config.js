
module.exports = {
  outputDir:"build"
}