### vue脚手架的安装
> npm i -g @vue/cli

### vue创建项目
> vue create [projectName]

### public 文件会原封不动的打包到项目

### vue.config.js (通过脚手架创建的vue项目)
> https://cli.vuejs.org/config/#css-requiremoduleextension
