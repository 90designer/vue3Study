module.exports={
  plugins:[
    // require('postcss-preset-env')()  // 两种方式
    [
      'postcss-preset-env',
      {
        // 其他选项
      },
    ],
  ]
}