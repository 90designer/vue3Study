import {one,two} from './common'

console.log(one(1,3))