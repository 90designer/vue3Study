export function one(x,y){
  return x+y
}

export function two(x,y){
  return x*y
}

