require('./lessStyle.less')
require('./sassStyle.scss')

console.log("这是测试js文件")