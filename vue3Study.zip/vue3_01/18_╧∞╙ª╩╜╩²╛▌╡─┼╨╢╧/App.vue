<template>
  <h2>响应式数据的判断</h2>
</template>
<script lang="ts">
  /**
   * isProxy 检查对象是 reactive 还是 readonly创建的代理
   * isReactive 检查对象是否是 reactive创建的响应式 proxy。
   * isReadonly 检查对象是否是由readonly创建的只读代理。
   * isRef 检查值是否为一个 ref 对象。
   */
  
  import { defineComponent,ref,isRef, isReactive, reactive, readonly,isReadonly ,isProxy} from 'vue';
  export default defineComponent({
    name: 'App',
    setup(){
      console.log(isRef(ref('')))
      console.log(isReactive(reactive({})))
      console.log(isReadonly(readonly({})))
      console.log(isProxy(readonly({})))
      
      const a = new Proxy({},{})
      console.log(isProxy(a))  // false
      return{
      }
    }
    
});

</script>