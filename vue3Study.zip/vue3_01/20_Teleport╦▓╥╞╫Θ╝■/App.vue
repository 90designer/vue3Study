<template>
  <h2>App父组件</h2>
  <modalButtonVue/>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import modalButtonVue from './modalButton.vue';
  export default defineComponent({
    name: 'App',
    components:{
        modalButtonVue
    },
    setup(){
      
      return{
      }
    }
});
</script>