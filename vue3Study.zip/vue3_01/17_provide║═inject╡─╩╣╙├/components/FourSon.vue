<template>
  <h2>第四层</h2>
  <h2>能不能获取的颜色值：{{color??"不能获取"}}</h2>
</template>
<script lang="ts">
  import { defineComponent, inject, provide, ref } from 'vue';
  export default defineComponent({
    name: 'FourSon',
    setup(){
      // 注入操作
      const color = inject('superColor')

      const Four = ref("this is from Four Son .")
      provide('four', Four)
      return{
        color
      }
    }
});
</script>