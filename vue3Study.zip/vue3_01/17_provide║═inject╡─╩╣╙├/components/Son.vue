<template>
  <h2>第二次</h2>
  <h2>能不能获取的颜色值：{{color??"不能获取"}}</h2>
  <h2>能不能获取子组件Provide的颜色值：{{fourFromSon??"不能获取"}}</h2>
  <hr>
  <GrandSon/>
</template>
<script lang="ts">
  import { defineComponent, inject } from 'vue';
  import GrandSon from "./GrandSon.vue"
  export default defineComponent({
    name: 'Son',
    components:{
      GrandSon
    },
    setup(){
      const color = inject<string>('superColor')

      // 是否能获取到子组件的provide(提供)的值
      const fourFromSon = inject<string>('four')
      return{
        color, fourFromSon
      }
    }
});
</script>