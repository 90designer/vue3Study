<template>
  <h2>toRefs的使用</h2>
  <h3>{{state.name}}</h3>
  <h3>{{state.age}}</h3>
  <h3>当前时间：{{state.clock}}</h3>
  <h3>obj:{{obj}}</h3>
  <h3>响应对象转为变量后：a={{a}},b={{b}}, 变为非响应数据</h3>
  <h3>{{obj2.c.value}}</h3>
  <h3>{{c}}</h3>
</template>
<script lang="ts">
  import { defineComponent, onMounted, reactive,  toRefs } from 'vue';
  export default defineComponent({
  name: 'App',
  setup(){
     // 自己玩的
    const state = reactive({
      name:"撒旦法",
      age:123,
      Hour: new Date().getHours(),
      Min: new Date().getMinutes(),
      Sec: new Date().getUTCSeconds(),
      clock:""
    })

    // 响应对象
    const obj = reactive({
      a:1, 
      b:2
    });
  
    /**
     *  toRefs 把一个响应式对象转换成普通对象，该普通对象的每个成员都是一个ref
    */
    // toRefs转换后
    const org = reactive({
      c:1, 
      d:2
    });
    const obj2 = toRefs(org)



    var splitStr = ":"
    state.clock = state.Hour+splitStr+state.Min+splitStr+state.Sec
    setInterval(function(){
      // 自己玩的
      splitStr = " "
      state.clock = state.Hour+splitStr+state.Min+splitStr+state.Sec
      setTimeout(() => {
        splitStr = ":"
        state.Hour = new Date().getHours()
        state.Min = new Date().getMinutes()
        state.Sec = new Date().getSeconds()
        state.clock = state.Hour+splitStr+state.Min+splitStr+state.Sec
      }, 200);

      // 修改obj的值
      obj.a += 1
      org.c += 2


    },1000)
    
    return {
      state,
      obj,
      ...obj,
      obj2,
      ...obj2
    }
    
  }
 
});
</script>