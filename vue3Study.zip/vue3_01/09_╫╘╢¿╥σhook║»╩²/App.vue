<template>
  <h2>自定义hook函数</h2>
  <h3>x:{{x}} ,y:{{y}}</h3>
  <h2 v-if="loadding">正在加载中...</h2>
  <h2 v-else-if="errorMsg">错误消息：{{errorMsg}}</h2>
  <!-- <ul v-else-if="data !== null">
      <li>id: {{data.id}}</li>
      <li>add: {{data.add}}</li>
      <li>distance: {{data.distance}}</li>
  </ul> -->
  <h2 v-else>未知错误</h2>

  <ul v-for="item in data" :key="item.id">
    <li>id: {{item.id}}</li>
      <li>add: {{item.add}}</li>
      <li>distance: {{item.distance}}</li>
  </ul>
</template>
<script lang="ts">
  import { defineComponent, watch,ref} from 'vue';
  import useMousePosition from './hooks/useMousePosition';
  import useRequest from './hooks/useRequest';

  interface IAdd{
    id:number
    add:string
    distance:string
  }
  export default defineComponent({
  name: 'App',

  // 【需求】：收集用户点击页面时的xy坐标
  setup(){
    const m1 = ref([
      {
        id:1,
        age:2
      },{
        id:2,
        age:4
      },{
        id:3,
        age:6
      }
    ])

    console.log("测试",typeof m1.value)

    console.log("测试", m1)

    const {x , y} = useMousePosition()
    // 发送
    // const {loadding, data, errorMsg } = useRequest<IAdd>("/data/add.json")
    const {loadding, data, errorMsg } = useRequest<IAdd[]>("/data/arr.json")
    
    // 此处输出data时，data.value还是null, 但是控制台点开查看确是有值的
    // 打印对象都是引用的，后续有更新展开后是更新的值(应该与then函数有关系)
    console.log("此处输出data",data)
    
    // 监视
    watch(data, ()=>{
      console.log("为啥？",data.value?.length)
    })
    return {
      x,y,loadding, data, errorMsg
    }
  }
});
</script>