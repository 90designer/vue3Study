<template>
<h2>setup和ref的基本使用</h2>
<h3>{{ count }}</h3>
<button @click="updateCount">点我啊</button>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  name: 'App',
  // vue2实现
  // data(){
  //   return {
  //     count:0,
  //   }
  // },
  // methods:{
  //   updateCount(){
  //     this.count++
  //   },
  // }

  // vue3实现
  // setup是组合API的入口函数
  setup(){
    // let count = 0;
    let count = ref(0)  // 定义一个（基本类型的）响应式数据，返回的是Ref对象
    function updateCount(){
      console.log(count)
        count.value++
    }
    return {
      count,
      updateCount,
    }
  }




});
</script>