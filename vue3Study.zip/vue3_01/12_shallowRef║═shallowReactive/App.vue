<template>
  <h2>shallowReactive和shallowRef</h2>
  <h3>m1:{{m1}}</h3>
  <h3>m2:{{m2}}</h3>
  <h3>m3:{{m3}}</h3>
  <h3>m4:{{m4}}</h3>
  <hr>
  <button @click="upM">更新数据</button>
</template>
<script lang="ts">
  import { defineComponent, reactive, ref, shallowReactive, shallowRef } from 'vue';
  export default defineComponent({
  name: 'App',
  setup(){
    // 深度响应
    const m1 = reactive({
      name:"名人",
      age:10,
      cars:{
        name:"奔驰",
        color:"red"
      }
    })
    // 浅响应
    // shallowReactive 监听第一层属性的值，一旦发生改变，则更新视图;
    // 其他层，虽然值发生了改变，但是视图不会进行更新
    const m2 = shallowReactive({
      name:"名人",
      age:10,
      cars:{
        name:"奔驰",
        color:"red"
      }
    })
    // 深度响应
    const m3 = ref({
      name:"名人",
      age:10,
      cars:{
        name:"奔驰",
        color:"red"
      }
    })
    // 浅响应 -- 只修改value值，不做reactive处理
    const m4 = shallowRef({
      name:"名人",
      age:10,
      cars:{
        name:"奔驰",
        color:"red"
      }
    })
    const upM = ()=>{
      // 更改m1的数据
      // m1.age += 2
      // m1.cars.name += "="

      // 更改m2的数据
      // m2.age += 3
      // m2.cars.name += "="

      // 更改m3的数据
      // m3.value.age += 3
      // m3.value.cars.name += "="

      // 更改m4的数据
      // m4.value.age += 4
      m4.value.cars.name+="="
      console.log(m4)
    }
    return{
      m1, m2, m3, m4,upM
    }
  }
});
</script>