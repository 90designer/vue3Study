<template>
  <h2>Chile子组件</h2>
  <h3>{{ msg }}</h3>
  <button @click="upMsg">更新</button>
</template>
<script lang="ts">
import { defineComponent,ref, onBeforeMount,onMounted,onBeforeUpdate,onUpdated,onBeforeUnmount,onUnmounted } from "vue";
export default defineComponent({
  name: "App",

  // vue2.X中的生命周期钩子
  beforeCreate() {
    console.log("2.x beaforCreate");
  },
  created() {
    console.log("2.x created");
  },
  beforeMount() {
    console.log("2.x beforeMount");
  },
  mounted() {
    console.log("2.x mounted");
  },
  beforeUpdate() {
    console.log("2.x beforeUpdate");
  },
  updated() {
    console.log("2.x updated");
  },
  beforeUnmount() {
    console.log("2.x beforeUnmount");
  },
  unmounted() {
    console.log("2.x unmounted");
  },

  setup(){
    console.log("3.x setup")
    const msg = ref("abc")
    const upMsg = ()=>{
      msg.value += "="
    }

    // 3.0中，都变为组合API， 需要先引入才能使用
    onBeforeMount(()=>{
      console.log("3.x onBeforeMount")
    })
    onMounted(()=>{
      console.log("3.x onMounted")
    })
    onBeforeUpdate(()=>{
      console.log("3.x onBeforeUpdate")
    })
    onUpdated(()=>{
      console.log("3.x onUpdated")
    })
    onBeforeUnmount(()=>{
      console.log("3.x onBeforeUnmount")
    })
    onUnmounted(()=>{
      console.log("3.x onUnmounted")
    })

    return {
      msg ,
      upMsg,
    }
  }
});
</script>