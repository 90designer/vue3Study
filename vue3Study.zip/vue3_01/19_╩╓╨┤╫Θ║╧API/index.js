// shallowReactive 与 reactive

// 定义一个reactiveHandler对象
const reactiveHanlder = {
  get(target, prop){
    const result = Reflect.get(target,prop)
    console.log("拦截数据的读取", prop, target)
    return result
  },
  set(target,prop,value){
    const result = Reflect.set(target,prop,value)
    console.log("拦截数据的设置", prop,value, target)
    return result
  },
  deleteProperty(target, prop){
    const result = Reflect.deleteProperty(target,prop)
    console.log("拦截数据的删除", prop, target)
    return result
  }      
}

// 定义一个shallowReactive函数， 传入一目标对象
function shallowReactive(target){
  // 判断当前目标对象是不是object类型(对象/数组)
  if (target && typeof target === 'object'){
    return new Proxy(target,reactiveHanlder)
  }
  // 基本数据，直接返回
  return target
}

function reactive(target){
  // 判断当前目标对象是不是object类型(对象/数组)
  if (target && typeof target === 'object'){
    if(Array.isArray(target)){
      target.forEach((item, index)=>{
        target[index] = reactive(item) 
      })
    }else{
      Object.keys(target).forEach(function(key){
        target[key] = reactive(target[key])
      })
    }
    return new Proxy(target, reactiveHanlder)
  }
  // 基本数据，直接返回
  return target
}


const readonlyHandler = {
  get(target, prop){
    const result = Reflect.get(target,prop)
    console.log("拦截数据的读取", prop, target)
    return result
  },
  set(target,prop,value){
    console.warn("不能设置数据", prop,value, target)
    return true
  },
  deleteProperty(target, prop){
    console.warn("不鞥呢删除")
    return true
  }      
}

function shallowReadonly(target){
  if(target && typeof target === 'object'){
    return new Proxy(target, readonlyHandler)
  }
  return target
}

function readonly(target){
  if(target && typeof target === 'object'){
    if(Array.isArray(target)){
      target.forEach((item, index)=>{
        target[index] = reactive(item) 
      })
    }else{
      Object.keys(target).forEach(function(key){
        target[key] = reactive(target[key])
      })
    }
    return new Proxy(target, readonlyHandler)
  }
  return target
}

// 后面几个手写没有学习...