https://hub.fastgit.org代替https://github.com

例如：
https://github.com/90designer/vue3
https://hub.fastgit.org/90designer/vue3
