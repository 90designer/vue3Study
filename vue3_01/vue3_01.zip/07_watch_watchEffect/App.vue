<template>
  <h2>计算属性和监视</h2>
  <fieldset>
    <legend>姓名操作</legend>
    姓氏：<input type="text"  v-model="user.firstName" /><br/>
    名字：<input type="text" v-model="user.lastName" />
  </fieldset>
  <fieldset>
    <legend>计算属性和监视的演示</legend>
    名字：<input type="text"  v-model="fullName"/><br/>
    名字：<input type="text"  v-model="fullName2"/><br/>
    名字：<input type="text" v-model="fullName3" />
  </fieldset>
</template>
<script lang="ts">
  import { computed, defineComponent, reactive, ref, watch, watchEffect } from 'vue';
  export default defineComponent({
  name: 'App',
  setup(){
    // 定义一个响应式的对象
    const user = reactive({
      firstName :"东边",
      lastName:"不败"
    })

    /**
     *  > computed需要引入
     *  > computed传一个函数参数，表示get
     *  
     */ 

    // 【需求】 通过计算属性的方式，显示第一个名字
    // 返回的是一个Ref类型的对象
    const fullName1 = computed(()=>{
        return user.firstName+user.lastName
    })
    const fullName2 = computed({
      get(){
        return user.firstName+ '_' +user.lastName
      },
      set(value:string){
        const names = value.split("_")
        user.firstName = names[0]
        user.lastName = names[1]
      }
    });

// 监视----监视指定数据
    const fullName3 = ref('')
    // watch(user, (val)=>{  // val就是前面传入的对象值
    watch(
      user, 
    ({firstName,lastName})=>{
        fullName3.value = firstName+ '_' + lastName
    },
    {immediate:true, deep:true}
    ) 
    // {immediate:true} 默认执行一次
    // {deep:true} 深度监视

// 监视--  不需要immediate配置，默认执行一次
    // watchEffect(()=>{
    //   fullName3.value = user.firstName+ '_' + user.lastName
    // })
// 监视
  watchEffect(()=>{
    const names = fullName3.value.split('_')
    user.firstName = names[0]
    user.lastName = names[1]
  })

// 监视 -- 多个数据
  // watch([user.firstName,user.lastName], ()=>{
  //   console.log(" = ") // watch监视非响应数据时，是不执行的
  // })

  // 监视 -- 多个数据，并且是非响应式的数据
  watch([()=>user.firstName,()=>user.lastName], ()=>{
    console.log(" = ") // 非响应式的参数要写成回调方式写法
  })

    return {
      user,
      fullName:fullName1,
      fullName2,
      fullName3

    }
  }
});
</script>