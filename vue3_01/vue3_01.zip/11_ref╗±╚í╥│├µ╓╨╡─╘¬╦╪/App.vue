<template>
  <h2>ref的另一个作用：可以获取页面中的元素</h2>

  <input type="text" ref="inputRef" class="aaa"/>
</template>
<script lang="ts">
  import { defineComponent, ref,onMounted} from 'vue';
  export default defineComponent({
  name: 'App',

  // 【需求】：页面加载完成，文本框自动获取焦点
  setup(){
    // 默认空
    const inputRef = ref<HTMLElement|null>(null)
    // 页面加载后
    onMounted(() => {
      // 存在，并获取焦点
      inputRef.value && inputRef.value.focus()
      if(inputRef.value){
        console.log("打印对象：",inputRef)
        console.log("打印是什么值：",inputRef.value)
        console.log("获取所有属性：",inputRef.value.attributes)
        console.log("判断是否有属性？：",inputRef.value.hasAttribute('type'))
        console.log("获取某个属性：",inputRef.value.className)
      }
    })
    return {
      inputRef
    }
  }

});
</script>