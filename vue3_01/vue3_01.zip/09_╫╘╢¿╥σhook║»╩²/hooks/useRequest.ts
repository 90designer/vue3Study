
// 引入axios
import { ref } from "vue"
import axios from "axios"

// 发送ajax的请求
export default function <T>(url:string){
  // 加载状态
  const loadding = ref(true)
  // 请求成功数据
  const data = ref<T| null>(null)
  // 错误消息
  const errorMsg = ref('')
  
  // 发送请求
  axios.get(url).then(res=>{
    // 修改加载状态
    loadding.value = false
    data.value = res.data
  },errmsg=>{
    loadding.value = false
    data.value = null
    errorMsg.value = errmsg.message || '未知错误'
  })
  
    return {
      loadding,
      data,
      errorMsg
    }
}