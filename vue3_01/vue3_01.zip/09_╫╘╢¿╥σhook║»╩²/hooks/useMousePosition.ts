import { onBeforeUnmount, onMounted, ref } from 'vue';
export default ()=>{
  const x = ref (-1)
  const y = ref (-1)
  // 只有页面加载完毕，才可以进行点击操作
  const clickHandler = (event:MouseEvent)=>{
         x.value = event.pageX
        y.value = event.pageY
    }
  onMounted(()=>{
    window.addEventListener('click',clickHandler)
  })
  onBeforeUnmount(()=>{
    window.removeEventListener('click', clickHandler)
  })
  
  return {x,y}
}