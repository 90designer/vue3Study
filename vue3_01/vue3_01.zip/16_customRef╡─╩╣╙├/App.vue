<template>
  <h2>customRef的使用</h2>
  <input type="text" v-model="keyworld" />
  <pre> {{keyworld}} </pre>
</template>
<script lang="ts">
  import { customRef, defineComponent,ref } from 'vue';
  // 自定义hook函数
  function useHookRef<T>(value:T, delay = 200){
    let timeoutId:number

    return customRef((track, trigger)=>{
      return {
        get(){
          // 告诉vue追踪数据
          track()
          return value
        },
        set(newValue:T){
          clearTimeout(timeoutId)
          timeoutId = setTimeout(() => {
            value = newValue
            // 告诉vue更新界面
            trigger()
          }, delay);
        }
      }
    })
  }
  export default defineComponent({
    name: 'App',
    setup(){
      // const keyworld = ref("abc")
      const keyworld = useHookRef('abc', 500)
      return{
        keyworld
      }
    }
});
</script>