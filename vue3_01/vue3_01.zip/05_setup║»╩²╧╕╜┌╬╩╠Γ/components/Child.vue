<template>
  <h2>子级组件</h2>
  <h3>{{ msgFromFathor }}</h3>
  <!-- <h3>{{ count }}</h3> -->
  <button @click='emitXxx'>分发事件</button>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  export default defineComponent({
  name: 'App',
  props:['msgFromFathor'], // 接收父组件传递的变量
  /**
   *  setup 细节问题：
   *  1. setup()在beforeCreate()之前执行，且只执行一次
   *  2. setup在执行时，当前组件还没有创建，意味着组件的实例对象this就不能使用
   *  3. setup()返回的对象中的属性和data函数返回的对象的属性合并为组件对象的属性
   *  4. setup()返回的对象中的属性和methods对象中的方法合并为组件对象的方法
   *  5. 尽量不要混用setup和data() / methods
   * 
   *   setup 参数问题：
   *  1. props参数 是父组件向子组件传递的参数，并且在子组件使用props接收的Proxy对象
   *  2. context参数 是一个对象，包含attrs Proxy对象（标签所有属性的集合）,emit方法（分发事件），slots对象（插槽）
   */

  // 数据初始化的生命周期回调
  // beforeCreate(){
  //     console.log("befroe函数执行",this)
  // },
  // 界面渲染完毕
  // mounted(){},
  setup(props, context){
    console.log(props)
    console.log(context)
    console.log(context.attrs.msg2)
    console.log("setup函数执行")
    const showMSG2 = ()=>{
      console.log("showmsg2")
    }
    const emitXxx = ()=>{
        context.emit('xxx','哈')
    }
    return {
        nae:11,
        showMSG2,
        emitXxx
      // setup一般都是返回一个对象，属性和方法都可以在HTML中直接使用
    }
  },
  // data(){
  //   return {
  //      count:11
  //   }
  // },
  // mounted(){
  //   console.log(this) // VUE3中this也是一个Proxy对象
  // } ,
  // methods:{
  //   showMSG(){
  //     console.log("showmsg")
  //   }
  // }
});
</script>