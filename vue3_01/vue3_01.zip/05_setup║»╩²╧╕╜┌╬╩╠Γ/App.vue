<template>
   <h2>父级组件</h2>
   <div>{{msg}}</div>

   <!-- 3. 使用子组件 -->

   <!-- 传递变量到子级组件 -->
   <Child :msgFromFathor='msg' msg2="真想" msg3="真想3" @xxx='xxx'/>

   <button @click="msg += '=='">更新msg</button>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
// 1. 引入子级组件
import Child from './components/Child.vue'
export default defineComponent({
  name: 'App',
  // 2. 注册组件
  components:{
    Child
  },
  setup(){
    function xxx(txt:string){
      msg.value += txt
    }
    const msg = ref("what are you from ？")
    return {msg,xxx}
  }
});

</script>