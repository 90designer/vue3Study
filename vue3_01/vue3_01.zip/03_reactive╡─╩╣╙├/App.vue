<template>
<h2>reactive的基本使用</h2>
<h3>名字：{{user.name}}</h3>
<h3>年龄：{{user.age}}</h3>
<h3>对象：{{user.wife}}</h3>
<button @click="upUser">更新数据</button>
</template>

<script lang="ts">
import { defineComponent, reactive } from 'vue';

export default defineComponent({
  name: 'App',
  // 显示用户相关信息，点击按钮更新用户数据

  // user是代理对象，reactive返回的是obj的代理对象Proxy
  setup(){
    const obj = {
      name:"us",
      age:20,
      wife:{
        name:'小短腿q',
        age:15,
        cars:[1,"2",3]
      }
    }
    const user = reactive(obj)

    const upUser = ()=>{
        user.name += "你好1"
        user.age +=2
        user.wife.cars.push("宝马")
        // obj.age = 1000  // 非响应
    }

    return {
      user,
      upUser
    }
  }

});
// Proxy 对象的练习
// https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Proxy

const handler = { // 有好多内置方法，在调用时触发
  get:function (obj, a){
    return a in obj ? obj[a]: 101
  },
  set(obj, a, b){
    b +=2
    return Reflect.set(obj, a,b)
  }, 
  has(obj, b){
    return b in obj
  },
  deleteProperty(target, keys){
    return Reflect.deleteProperty(target, keys)
  }
}

const p = new Proxy({}, handler)
p.b = 120
p.a = '哈哈'
p.AAA = "!@#"
console.log(p.a,"设置：",p.b, 'b' in p);
delete p.AAA
console.log(p)
</script>