<template>
  <button @click="modalOpen=true">
    打开对话框
  </button>
  <!-- 瞬移组件，移动到to指定的位置 -->
  <Teleport to="body">
    <div v-if="modalOpen">
    <div>
      这是对话框
    </div>
    <button @click="modalOpen=false">关闭</button>
  </div>
  </Teleport>
  
</template>
<script lang="ts">
  import { defineComponent ,ref} from 'vue';
  export default defineComponent({
    name: 'App',
    setup(){
      const modalOpen = ref(false)
      return{
        modalOpen
      }
    }
});
</script>