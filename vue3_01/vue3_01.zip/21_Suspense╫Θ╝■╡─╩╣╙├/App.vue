<template>
  <h2>Suspense组件的使用</h2>
  
  <!-- 异步操作完成之前，界面的处理 -->
  <Suspense>
    <template v-slot:default>
      <!-- 异步组件要显示的内容 -->
      <asyncComponent />
    </template>
    <template v-slot:fallback>
      <!-- 加载完成前，要显示内容 -->
      <h2>loadding。。。</h2>
    </template>
  </Suspense>


</template>
<script lang="ts">
  import { defineComponent,defineAsyncComponent } from 'vue';
  //  vue2动态引入组件的写法( Vue3中这种写法不可使用了)
  // const asyncComponent = ()=>import('./AsynComponent.vue')

  // vue3动态引入组件的写法
  // let asyncComponent = defineAsyncComponent(
  //   ()=> import('./AsynComponent.vue')
  // )

  // 静态引入组件
  import asyncComponent from './AsynComponent.vue'
  export default defineComponent({
    name: 'App',
    components:{
      asyncComponent
    },
    setup(){
      return{
      }
    }
});
</script>