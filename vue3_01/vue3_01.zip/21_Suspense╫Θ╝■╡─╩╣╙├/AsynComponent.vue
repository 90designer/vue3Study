<template>
  <h2>子级组件</h2>
  <h3>{{ msg }}</h3>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import axios from 'axios'

  export default defineComponent({
    name: 'Async',
    // 异步请求1：
    // setup(){
    //   return new Promise((resolve, reject)=>{
    //       setTimeout(() => {
    //         resolve({
    //           msg:"你才对了"
    //         })
    //       }, 2000);
    //   })
    // }
    // 异步请求2：
    // async setup(){
    //   const res = await axios.get('/data/add.json')
    //   return {
    //     msg: res.data
    //   }
    // }
    setup(){
      return axios.get('/data/add.json').then(response=>{
        return {
          msg: response.data
        }
      }, err=>{
        console.error(err)
      })
     
    }
});
</script>