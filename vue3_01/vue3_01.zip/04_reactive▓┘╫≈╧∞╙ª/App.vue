<template>
<h2>操作代理数据</h2>
<h3>年龄：{{user.age}}</h3>
<h3>笑：{{user.haha}}</h3>
<h3>对象：{{user.wife}}</h3>
<button @click="upUser">更新数据</button>
</template>

<script lang="ts">
import { defineComponent, reactive } from 'vue';

export default defineComponent({
  name: 'App',
  setup(){
    const obj = {
      age:10,
      wife:[1,'2',3]
    }

    const user = reactive<any>(obj)
    const upUser = ()=>{
        // obj.haha = 100 // 页面没有响应，代理对象也没有变化，但是obj有次属性了
        user.haha = 120+Math.random() // 页面响应了，obj也发生变化了
        console.log(obj)
        setTimeout(() => {
          delete user.haha // 页面响应了，obj也发生变化了
          console.log(obj)
        }, 1000);
    }
    return {
      user,upUser
    }
  }
});
</script>