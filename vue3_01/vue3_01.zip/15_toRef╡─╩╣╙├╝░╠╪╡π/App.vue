<template>
  <h2>toRef的使用及特点</h2>
  <h3>state {{state}}</h3>
  <h3>age {{age}}</h3>
  <h3>money {{money}}</h3>
  <button @click="update">更细</button>
</template>
<script lang="ts">
  import { defineComponent, reactive, ref, toRef } from 'vue';
  export default defineComponent({
    name: 'App',
    setup(){
      const state = reactive({
        age:5,
        money:100
      })

      // toref---->引用，修改响应式数据，会影响原始数据
      const age = toRef(state, 'age')
      // ref---->复制，修改响应式数据不会影响原始数据
      const money = ref(state.money)
      console.log("AGE",age)
      console.log("money",money)
      const update = ()=>{
        // state.age +=4
        // state.money += 100
        // money.value += 4
        age.value +=2
      }
      return{
        state,age,money,update
      }
    }
});
</script>