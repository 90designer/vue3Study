<template>
  <h2>readonly 和 shallowReadonly</h2>
  <h3>state2:{{state2}}</h3>
  <button @click="up">更新</button>
</template>
<script lang="ts">
  import { defineComponent, reactive, readonly, shallowReadonly } from 'vue';
  export default defineComponent({
  name: 'App',
  setup(){
    const state = reactive({
      age:11111,
      cars:{
        name:"大本",
        color:"对对对"
      }
    });
    // 深度只读
    // const state2 = readonly(state)
    
    // 浅只读， 只监视第一层
    const state2 = shallowReadonly(state)
    const up = ()=>{
      state2.cars.name += 2
      console.log(state2.age)
    }
    return {
      up,state2
    }
  }
});
</script>