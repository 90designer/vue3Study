<template>
  <h2>reactive 和 ref 的细节问题</h2>
  <h3>{{ m1 }}</h3>
  <h3>{{ m2 }}</h3>
  <h3>{{ m3 }}</h3>
  <button @click="up">更新</button>
  <div></div>
</template>
<script lang="ts">
  import { defineComponent, reactive, ref } from 'vue';
  export default defineComponent({
  name: 'App',

  /**
   * composition API中最重要的响应式API：ref 和 reactive
   * > ref用来处理基本数据类型，  reactive用来处理对象
   * > 如果ref传入对象/数组，内部会自动将对象、数组转换为reactive的代理对象，即value的值为proxy对象
   */
  setup(){
    const m1 = ref('abc')
    const m2 = reactive({
      name:'小小',
      wife:{
        name:"小黑"
      }
    })
    const m3 = ref({
      name:'小小',
      wife:{
        name:"小黑"
      }
    })
    const m4 = ref([1,2,3])
    const up = ()=>{
      console.log(m2)
      console.log(m3)
      console.log(m4)
        m1.value += '='
        m2.wife.name +='|'
        m3.value.name += ']'
        m3.value.wife.name += '?'
    }
    return {
        m1,m2,m3,up
    }
  }
});
</script>