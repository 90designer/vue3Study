<template>
  <h2>第三层</h2>
  <h3 :style="{color:superColor}">获取的顶层color的值: {{ superColor }}</h3>
  <div :style="{ color: activeColor }"></div>
  <hr>
  <FourSon />
</template>
<script lang="ts">
  import { defineComponent, inject } from 'vue';
  import FourSon from "./FourSon.vue"
  export default defineComponent({
    name: 'GrandSon',
    components:{
      FourSon
    },
    setup(){
      const superColor = inject<string>('superColor')
      return{
        superColor,
        activeColor:"red"
      }
    }
});
</script>