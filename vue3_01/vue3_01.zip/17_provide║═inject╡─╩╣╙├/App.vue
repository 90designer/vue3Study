<template>
  <h2>provide和inject的使用</h2>
  <h3>第一层</h3>
  <h3>当前颜色值:{{ color }}</h3>
  <button @click="upColor('red')">红色</button>
  <button @click="upColor('green')">绿色</button>
  <button @click="upColor('blueviolet')">紫色</button>
  <button @click="upColor('royalblue')">蓝色</button>
  <button @click="upColor('darkred')">深红色</button>
  <hr>
  <Son />
</template>
<script lang="ts">
  /**
   *  provide 提供 / inject 注入
   *  1. 父组件通过provide('aliasname', property) 函数提供一个变量，使深层次的子组件可以获取到。
   *  2. 深层次的子组件通过inject('aliasname')函数注入此变量。
   */
  import { defineComponent, provide, ref } from 'vue';
  import Son from "./components/Son.vue"
  export default defineComponent({
    name: 'App',
    components:{
        Son
    },
    setup(){
      const color = ref('steelblue')
      // 提供操作
      provide('superColor', color)
      const upColor = (colorStr:string)=>{
        color.value = colorStr
      }
      return{
        color,upColor
      }
    }
});
</script>