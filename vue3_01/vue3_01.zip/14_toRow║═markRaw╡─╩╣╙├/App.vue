<template>
  <h2>toRow和markRaw的使用</h2>
  <h3>state{{state}}</h3>
  <hr>
  <button @click="testRaw">测试toRaw</button>
  <button @click="testMarkRaw">测试markRaw</button>
</template>
<script lang="ts">
  import { defineComponent, markRaw, reactive, toRaw ,readonly} from 'vue';
  interface UserInfo{
    name:string
    age:number
    cars?:Array<string>
  }
  export default defineComponent({
  name: 'App',
  setup(){
    const state = reactive<UserInfo>({
      name:"aaa",
      age:11
    })

    const testRaw = ()=>{
      // 将代理对象转为普通对象
      const user = toRaw(state)
      user.name += "=="
      console.log("测试1")
    }
    const testMarkRaw = ()=>{
      console.log("测试")
      const cars = ["AA","BB"];
      // 普通对象不能被readonly和reactive
      state.cars = markRaw(cars)
      setInterval(()=>{
          state.cars && (state.cars[0] += '0')
          console.log(state)
      }, 2000)
      
    }

    return {
      state,
      testRaw,
      testMarkRaw
    }
  }
});
</script>